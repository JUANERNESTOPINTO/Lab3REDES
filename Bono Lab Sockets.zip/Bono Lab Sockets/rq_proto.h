#pragma once
#include <stdint.h>

#define RQ_PORT            8081
#define RQ_MSS             1024
#define RQ_INIT_RTO_MS     300

// Tipos de mensaje de aplicación
#define RQ_APP_SUBSCRIBE   0x01
#define RQ_APP_DATA        0x02

// Banderas del header
enum { RQ_SYN=1, RQ_ACK=2, RQ_FIN=4, RQ_DATA=8 };

#pragma pack(push,1)
typedef struct {
    uint32_t conn_id;    // conexión lógica
    uint16_t stream_id;  // no se usa en el header en esta versión (0)
    uint32_t seq;        // numeración por segmento
    uint32_t ack;        // ACK acumulativo (último seq correcto)
    uint16_t wnd;        // ventana anunciada (no usada en stop&wait)
    uint8_t  flags;      // RQ_SYN|RQ_ACK|RQ_FIN|RQ_DATA
    uint16_t len;        // bytes de payload
    uint32_t csum;       // checksum simple (opcional)
} rq_hdr_t;
#pragma pack(pop)

#pragma pack(push,1)
typedef struct {
    uint8_t  app_type;   // RQ_APP_SUBSCRIBE o RQ_APP_DATA
    uint16_t stream_id;  // id del tema/partido
    uint16_t rsv;        // padding
} rq_app_t;
#pragma pack(pop)

// Encode/Decode
int  rq_encode(const rq_hdr_t* h, const uint8_t* payload, int plen, uint8_t* out, int outsz);
int  rq_decode(const uint8_t* in, int insz, rq_hdr_t* h, const uint8_t** payload);
uint32_t rq_checksum(const uint8_t* p, int n);
