#pragma once
#include <stdint.h>
#include <sys/time.h>
#include <netinet/in.h>

int  udp_open_bind(int port); // para broker
int  udp_open(void);          // para clientes
int  udp_send(int s, const void* p, int n, const struct sockaddr_in* to);
int  udp_recv(int s, uint8_t* buf, int bufsz, struct sockaddr_in* from, int timeout_ms);

int  ms_now(void);
int  ms_diff(struct timeval a, struct timeval b);
