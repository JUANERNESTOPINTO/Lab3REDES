#include "rq_sock.h"
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <sys/select.h>
#include <arpa/inet.h>

int udp_open_bind(int port) {
    int s = socket(AF_INET, SOCK_DGRAM, 0);
    if (s < 0) return -1;
    int yes=1; setsockopt(s, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));
    struct sockaddr_in a; memset(&a,0,sizeof(a));
    a.sin_family = AF_INET; a.sin_addr.s_addr = INADDR_ANY; a.sin_port = htons(port);
    if (bind(s, (struct sockaddr*)&a, sizeof(a)) < 0) { close(s); return -2; }
    return s;
}

int udp_open(void) {
    return socket(AF_INET, SOCK_DGRAM, 0);
}

int udp_send(int s, const void* p, int n, const struct sockaddr_in* to) {
    return (int)sendto(s, p, n, 0, (const struct sockaddr*)to, sizeof(*to));
}

int udp_recv(int s, uint8_t* buf, int bufsz, struct sockaddr_in* from, int timeout_ms) {
    fd_set rfds; FD_ZERO(&rfds); FD_SET(s, &rfds);
    struct timeval tv; tv.tv_sec = timeout_ms/1000; tv.tv_usec=(timeout_ms%1000)*1000;
    int r = select(s+1, &rfds, NULL, NULL, timeout_ms>=0?&tv:NULL);
    if (r <= 0) return r; // 0 timeout, -1 error
    socklen_t slen = sizeof(*from);
    return (int)recvfrom(s, buf, bufsz, 0, (struct sockaddr*)from, &slen);
}

int ms_now(void) {
    struct timespec ts; clock_gettime(CLOCK_REALTIME, &ts);
    return (int)(ts.tv_sec*1000 + ts.tv_nsec/1000000);
}

int ms_diff(struct timeval a, struct timeval b) {
    long ms = (a.tv_sec - b.tv_sec)*1000 + (a.tv_usec - b.tv_usec)/1000;
    return (int)ms;
}
