#include "rq_conn.h"
#include "rq_proto.h"
#include "rq_sock.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <time.h>

int main(int argc,char**argv){
    if(argc<3){printf("Uso: %s <IP_BROKER> <stream_id>\n",argv[0]);return 1;}
    const char*ip=argv[1]; uint16_t sid=atoi(argv[2]);
    srand((unsigned)time(NULL));
    int sock=udp_open(); struct sockaddr_in b={0};
    b.sin_family=AF_INET; b.sin_port=htons(RQ_PORT); inet_pton(AF_INET,ip,&b.sin_addr);
    rq_conn_t c;
    rq_client_connect(&c,sock,b);
    printf("[subscriber] conectado. Suscribiéndome a stream %u...\n",sid);
    rq_send_app(&c,RQ_APP_SUBSCRIBE,sid,NULL,0);
    printf("[subscriber] Esperando eventos...\n");
    while(1){
        uint8_t t; uint16_t s; uint8_t buf[1024];
        int r=rq_recv_app(&c,&t,&s,buf,sizeof(buf)-1,500);
        if(r>0){buf[r]=0;printf("[subscriber] stream=%u msg='%s'\n",s,buf);}
    }
}
