#include "rq_conn.h"
#include "rq_proto.h"
#include "rq_sock.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <time.h>

#define MAX_CONNS   128
#define MAX_SUBS    128

typedef struct { int used; rq_conn_t conn; } slot_t;
typedef struct { uint16_t stream_id; rq_conn_t* subs[MAX_SUBS]; int nsubs; } topic_t;

static slot_t g_conns[MAX_CONNS];
static topic_t g_topics[MAX_CONNS];

static rq_conn_t* find_conn_by_id(uint32_t conn_id) {
    for (int i=0;i<MAX_CONNS;i++)
        if (g_conns[i].used && g_conns[i].conn.conn_id == conn_id)
            return &g_conns[i].conn;
    return NULL;
}

static rq_conn_t* accept_new_conn(int sock, const rq_hdr_t* h, const struct sockaddr_in* from) {
    for (int i=0;i<MAX_CONNS;i++) if (!g_conns[i].used) {
        g_conns[i].used = 1;
        rq_server_accept(&g_conns[i].conn, sock, h, from);
        printf("[broker] Nueva conexión aceptada: conn_id=%u\n", g_conns[i].conn.conn_id);
        return &g_conns[i].conn;
    }
    return NULL;
}

static topic_t* get_topic(uint16_t stream_id) {
    for (int i=0;i<MAX_CONNS;i++) {
        if (g_topics[i].stream_id == stream_id && g_topics[i].nsubs > 0) return &g_topics[i];
        if (g_topics[i].stream_id == 0) { g_topics[i].stream_id = stream_id; return &g_topics[i]; }
    }
    return NULL;
}

static void add_subscriber(uint16_t stream_id, rq_conn_t* c) {
    topic_t* t = get_topic(stream_id);
    if (!t) return;
    for (int i=0;i<t->nsubs;i++) if (t->subs[i] == c) return;
    if (t->nsubs < MAX_SUBS) t->subs[t->nsubs++] = c;
    printf("[broker] SUB conn_id=%u to stream=%u (nsubs=%d)\n", c->conn_id, stream_id, t->nsubs);
}

static void forward_to_subs(uint16_t stream_id, const char* msg, int len) {
    topic_t* t = get_topic(stream_id);
    if (!t) return;
    for (int i=0;i<t->nsubs;i++) {
        rq_send_app(t->subs[i], RQ_APP_DATA, stream_id, (const uint8_t*)msg, len);
    }
}

static void broker_send_ack(rq_conn_t* c, uint32_t ackseq) {
    rq_hdr_t ack = {0};
    uint8_t out[sizeof(rq_hdr_t)];
    ack.conn_id = c->conn_id;
    ack.flags   = RQ_ACK;
    ack.seq     = c->next_seq;
    ack.ack     = ackseq;
    ack.len     = 0;
    int n = rq_encode(&ack, NULL, 0, out, (int)sizeof(out));
    udp_send(c->sockfd, out, n, &c->peer);
}

int main(void) {
    srand((unsigned)time(NULL));
    int sock = udp_open_bind(RQ_PORT);
    if (sock < 0) { perror("udp_open_bind"); return 1; }
    printf("Broker QUIC-lite listo en UDP:%d\n", RQ_PORT);

    memset(g_conns,0,sizeof(g_conns));
    memset(g_topics,0,sizeof(g_topics));

    while (1) {
        uint8_t raw[1500]; struct sockaddr_in from;
        int r = udp_recv(sock, raw, (int)sizeof(raw), &from, 50);
        if (r > 0) {
            rq_hdr_t h; const uint8_t* pl;
            if (rq_decode(raw, r, &h, &pl) == 0) {
                if (h.flags & RQ_SYN) { accept_new_conn(sock, &h, &from); continue; }

                rq_conn_t* c = find_conn_by_id(h.conn_id);
                if (!c) continue;

                if (h.flags & RQ_DATA) {
                    if (h.seq == c->expected) {
                        if (h.len >= (int)sizeof(rq_app_t)) {
                            rq_app_t app; memcpy(&app, pl, sizeof(app));
                            int dlen = h.len - (int)sizeof(app);
                            char text[1024]={0};
                            if (dlen > 0) { int m = dlen<1023?dlen:1023; memcpy(text, pl+sizeof(app), m); }
                            c->expected += 1;
                            broker_send_ack(c, h.seq);

                            if (app.app_type == RQ_APP_SUBSCRIBE) {
                                add_subscriber(app.stream_id, c);
                            } else if (app.app_type == RQ_APP_DATA) {
                                forward_to_subs(app.stream_id, text, (int)strlen(text));
                                printf("[broker] stream=%u msg='%s'\n", app.stream_id, text);
                            }
                        } else {
                            c->expected += 1;
                            broker_send_ack(c, h.seq);
                        }
                    } else {
                        broker_send_ack(c, c->expected - 1);
                    }
                }
            }
        }
        for (int i=0;i<MAX_CONNS;i++) if (g_conns[i].used) rq_tick(&g_conns[i].conn);
    }
    return 0;
}
