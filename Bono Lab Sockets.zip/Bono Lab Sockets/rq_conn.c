#include "rq_conn.h"
#include "rq_proto.h"
#include "rq_sock.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/time.h>
#include <unistd.h>

// Generador aleatorio simple
static uint32_t rand32(void){ return (uint32_t)rand(); }

// Envío de header + payload
static int send_hdr_payload(rq_conn_t* c, const rq_hdr_t* h, const uint8_t* data, int len){
    uint8_t out[1500];
    int n = rq_encode(h, data, len, out, sizeof(out));
    return udp_send(c->sockfd, out, n, &c->peer);
}

//---------------- CLIENTE ----------------//
int rq_client_connect(rq_conn_t* c, int sockfd, struct sockaddr_in peer){
    memset(c,0,sizeof(*c));
    c->sockfd=sockfd; c->peer=peer;
    c->conn_id = rand32();
    c->next_seq = 1;
    c->expected = 1;
    c->rto_ms = RQ_INIT_RTO_MS;

    rq_hdr_t syn = {0};
    syn.conn_id = c->conn_id;
    syn.flags = RQ_SYN;
    syn.seq = c->next_seq;
    syn.len = 0;
    send_hdr_payload(c,&syn,NULL,0);

    uint8_t raw[1500]; struct sockaddr_in from;
    int r = udp_recv(c->sockfd,raw,sizeof(raw),&from,500);
    if(r<=0) return -1;
    rq_hdr_t h; const uint8_t* pl;
    if(rq_decode(raw,r,&h,&pl)!=0) return -1;
    if(!(h.flags & RQ_SYN) || !(h.flags & RQ_ACK)) return -1;

    rq_hdr_t ack = {0};
    ack.conn_id = c->conn_id;
    ack.flags = RQ_ACK;
    ack.seq = ++c->next_seq;
    ack.ack = h.seq;
    send_hdr_payload(c,&ack,NULL,0);

    c->established = 1;
    return 0;
}

//---------------- SERVIDOR ----------------//
int rq_server_accept(rq_conn_t* c, int sockfd, const rq_hdr_t* syn, const struct sockaddr_in* from){
    memset(c,0,sizeof(*c));
    c->sockfd = sockfd;
    c->peer = *from;
    c->conn_id = syn->conn_id ? syn->conn_id : rand32();
    c->next_seq = 1;
    c->expected = syn->seq + 1;   // <-- 🔧 clave: esperar el siguiente después del SYN
    c->rto_ms = RQ_INIT_RTO_MS;
    c->is_server = 1;

    rq_hdr_t hs = {0};
    hs.conn_id = c->conn_id;
    hs.flags = RQ_SYN | RQ_ACK;
    hs.seq = c->next_seq;
    hs.ack = syn->seq;
    hs.len = 0;
    send_hdr_payload(c,&hs,NULL,0);

    c->established = 1;
    return 0;
}

//---------------- APP DATA ----------------//
int rq_send_app(rq_conn_t* c, uint8_t app_type, uint16_t stream, const uint8_t* msg, int len){
    rq_app_t app = {app_type, stream};
    uint8_t payload[1500];
    memcpy(payload,&app,sizeof(app));
    if(len>0 && msg) memcpy(payload+sizeof(app),msg,len);
    int total = sizeof(app)+len;

    rq_hdr_t h = {0};
    h.conn_id = c->conn_id;
    h.flags = RQ_DATA;
    h.seq = c->next_seq++;
    h.len = total;
    send_hdr_payload(c,&h,payload,total);
    return 0;
}

int rq_recv_app(rq_conn_t* c, uint8_t* app_type, uint16_t* stream, uint8_t* buf, int bufsz, int timeout_ms){
    uint8_t raw[1500]; struct sockaddr_in from;
    int r = udp_recv(c->sockfd,raw,sizeof(raw),&from,timeout_ms);
    if(r<=0) return 0;
    rq_hdr_t h; const uint8_t* pl;
    if(rq_decode(raw,r,&h,&pl)!=0) return 0;
    if(!(h.flags & RQ_DATA)) return 0;
    if(h.conn_id != c->conn_id) return 0;

    if(h.len < sizeof(rq_app_t)) return 0;
    rq_app_t app; memcpy(&app,pl,sizeof(app));
    *app_type = app.app_type;
    *stream = app.stream_id;
    int dlen = h.len - sizeof(app);
    if(dlen>0 && buf && bufsz>0){
        int m = dlen<bufsz?dlen:bufsz;
        memcpy(buf,pl+sizeof(app),m);
        buf[m]=0;
        return m;
    }
    return 0;
}

void rq_tick(rq_conn_t* c){ (void)c; } // placeholder
