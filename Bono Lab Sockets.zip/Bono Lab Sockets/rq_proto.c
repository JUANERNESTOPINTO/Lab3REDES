#include "rq_proto.h"
#include <string.h>

uint32_t rq_checksum(const uint8_t* p, int n) {
    // XOR simple para demo (puedes cambiarlo por CRC32 si quieres)
    uint32_t x = 0;
    for (int i=0;i<n;i++) x ^= p[i];
    return x;
}

int rq_encode(const rq_hdr_t* h, const uint8_t* payload, int plen, uint8_t* out, int outsz) {
    if (outsz < (int)sizeof(rq_hdr_t) + plen) return -1;
    memcpy(out, h, sizeof(rq_hdr_t));
    if (plen > 0 && payload) memcpy(out + sizeof(rq_hdr_t), payload, plen);
    rq_hdr_t* oh = (rq_hdr_t*)out;
    oh->csum = 0;
    oh->csum = rq_checksum(out, (int)sizeof(rq_hdr_t)+plen);
    return (int)sizeof(rq_hdr_t) + plen;
}

int rq_decode(const uint8_t* in, int insz, rq_hdr_t* h, const uint8_t** payload) {
    if (insz < (int)sizeof(rq_hdr_t)) return -1;
    memcpy(h, in, sizeof(rq_hdr_t));
    *payload = in + sizeof(rq_hdr_t);
    if (h->len + (int)sizeof(rq_hdr_t) > insz) return -3;
    // si quisieras validar checksum: recalcular y comparar h->csum
    return 0;
}
