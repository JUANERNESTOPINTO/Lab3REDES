#include "rq_conn.h"
#include "rq_proto.h"
#include "rq_sock.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <time.h>

int main(int argc,char**argv){
    if(argc<3){printf("Uso: %s <IP_BROKER> <stream_id>\n",argv[0]);return 1;}
    const char*ip=argv[1]; uint16_t sid=atoi(argv[2]);
    srand((unsigned)time(NULL));
    int sock=udp_open(); struct sockaddr_in b={0};
    b.sin_family=AF_INET; b.sin_port=htons(RQ_PORT); inet_pton(AF_INET,ip,&b.sin_addr);
    rq_conn_t c;
    rq_client_connect(&c,sock,b);
    printf("[publisher] conectado. Enviando eventos a stream %u...\n",sid);
    for(int i=0;i<10;i++){
        char msg[64]; sprintf(msg,"Gol equipo A minuto %d",13+i);
        rq_send_app(&c,RQ_APP_DATA,sid,(const uint8_t*)msg,(int)strlen(msg));
        printf("[publisher] enviado: %s\n",msg);
        sleep(1);
    }
}
