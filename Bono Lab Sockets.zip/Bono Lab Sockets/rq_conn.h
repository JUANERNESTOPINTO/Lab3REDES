#pragma once
#include "rq_proto.h"
#include "rq_sock.h"
#include <netinet/in.h>

// NOTA: rq_app_t ya está definido en rq_proto.h. No volver a definirlo aquí.

typedef struct {
    uint32_t next_seq;           // siguiente seq a usar al enviar
    uint32_t expected;           // próximo seq esperado para recibir en orden
    int      sockfd;
    struct sockaddr_in peer;
    uint32_t conn_id;
    int      established;
    int      is_server;
    int      rto_ms;
} rq_conn_t;

// Cliente: SYN -> SYN|ACK -> ACK
int  rq_client_connect(rq_conn_t* c, int sockfd, struct sockaddr_in peer);

// Servidor: procesa SYN entrante y responde SYN|ACK
int  rq_server_accept(rq_conn_t* c, int sockfd, const rq_hdr_t* syn, const struct sockaddr_in* from);

// Envío fiable de mensaje de aplicación (DATA con rq_app_t + payload)
int  rq_send_app(rq_conn_t* c, uint8_t app_type, uint16_t stream, const uint8_t* msg, int len);

// Recepción fiable (devuelve bytes del payload; 0 si nada)
int  rq_recv_app(rq_conn_t* c, uint8_t* app_type, uint16_t* stream, uint8_t* buf, int bufsz, int timeout_ms);

// Timers (placeholder en esta versión)
void rq_tick(rq_conn_t* c);
